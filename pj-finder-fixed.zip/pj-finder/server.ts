import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import axios from 'axios';
import * as cheerio from 'cheerio';
import nodemailer from 'nodemailer';
import cron from 'node-cron';
import fs from 'fs/promises';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from "@google/genai";
import multer from 'multer';

// Safely derive filename and directory name for both ESM (tsx) and CJS (compiled node)
const resolvedFilename = (typeof import.meta !== 'undefined' && import.meta?.url)
  ? fileURLToPath(import.meta.url)
  : (typeof __filename !== 'undefined' ? __filename : '');

const resolvedDirname = (typeof import.meta !== 'undefined' && import.meta?.url)
  ? path.dirname(resolvedFilename)
  : (typeof __dirname !== 'undefined' ? __dirname : '');

let aiInstance: GoogleGenAI | null = null;
function getAI(): GoogleGenAI {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY environment variable is required but not configured.');
    }
    aiInstance = new GoogleGenAI({ 
      apiKey,
      httpOptions: { headers: { 'User-Agent': 'aistudio-build' } }
    });
  }
  return aiInstance;
}

const PORT = 3000;
const BASE_URL = 'https://www.praktischarzt.de';
const START_URL = 'https://www.praktischarzt.de/praktisches-jahr/?job_category&job_location&employment_type&employer_type&country&radius=30';
const DATA_DIR = path.join(process.cwd(), 'data');
const POSITIONS_FILE = path.join(DATA_DIR, 'positions.json');
const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');

// Multer setup
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    await fs.mkdir(UPLOADS_DIR, { recursive: true });
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  }
});
const upload = multer({ storage });

// Types
interface Position {
  id: string;
  title: string;
  hospital: string;
  city: string;
  url: string;
  specialty: string;
  unterkunft: boolean;
  verguetung: string | null;
  details: string;
  ansprechpartner: string;
  ansprechpartnerPosition: string;
  email: string;
  phone: string;
  bewerbung: string;
  dateFound: string;
  lastSeen: string;
}

interface ScraperStatus {
  isRunning: boolean;
  lastRun: string | null;
  foundCount: number;
  currentPage: number;
  error: string | null;
}

// Scraper State
let scraperStatus: ScraperStatus = {
  isRunning: false,
  lastRun: null,
  foundCount: 0,
  currentPage: 0,
  error: null,
};

let positions: Position[] = [];

// Helper functions for extraction
const SPECIALTY_MAP: Record<string, string> = {
  chirurgie: 'Chirurgie',
  viszeralchirurg: 'Chirurgie',
  unfallchirurg: 'Chirurgie',
  innere: 'Innere Medizin',
  interne: 'Innere Medizin',
  kardiolog: 'Innere Medizin',
  gastroenterolog: 'Innere Medizin',
  paediat: 'Pädiatrie',
  kinderheilkunde: 'Pädiatrie',
  kinderchirurg: 'Pädiatrie',
  gynaekolog: 'Gynäkologie',
  gynaekologie: 'Gynäkologie',
  frauenheilkunde: 'Gynäkologie',
  allgemeinmedizin: 'Allgemeinmedizin',
  neurolog: 'Neurologie',
  psychiatr: 'Psychiatrie',
  anaesthesie: 'Anästhesie',
  anaesthet: 'Anästhesie',
  radiolog: 'Radiologie',
  strahlentherap: 'Radiologie',
  orthopaedie: 'Orthopädie',
  orthopädie: 'Orthopädie',
  urolog: 'Urologie',
  dermatolog: 'Dermatologie',
  hno: 'HNO',
  augenheilkunde: 'Augenheilkunde',
  notaufnahme: 'Notaufnahme',
  notfallmedizin: 'Notaufnahme',
  onkolog: 'Onkologie',
  haematolog: 'Onkologie',
};

function detectSpecialty(url: string, title: string): string {
  const combined = (url + ' ' + title).toLowerCase()
    .replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss');
  for (const [kw, label] of Object.entries(SPECIALTY_MAP)) {
    if (combined.includes(kw)) return label;
  }
  return 'Sonstiges';
}

function extractVerguetung(text: string): string | null {
  const m = text.match(/(\d{2,4}(?:[.,]\d{1,2})?)\s*(?:Euro|€|EUR)/i);
  if (m) {
    const val = m[1].replace(',', '.');
    return `${Math.floor(parseFloat(val))} €/Monat`;
  }
  return null;
}

function detectUnterkunft(text: string): boolean {
  const t = text.toLowerCase();
  if (/keine\s+unterkunft/i.test(t)) return false;
  return /(kostenlos\w*\s+unterkunft|freie?\s+unterkunft|unterkunft\s+\w{1,10}\s*(kostenlos|frei|gestellt|inklusive|wird)|personalwohnheim|pj.wohnheim|wohnheim|kostenlos\w*\s+appartement|kostenlos\w*\s+zimmer|kostenlos\w*\s+unterbringung|zimmer\s+zur\s+verf.gung|unterbringung\s+\w{1,20}\s*kostenlos)/i.test(t);
}

// Mailer function
async function sendNotification(position: Position) {
  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, NOTIFICATION_EMAIL } = process.env;
  if (!SMTP_HOST || !SMTP_USER || !SMTP_PASS || !NOTIFICATION_EMAIL) {
    console.warn('Email notification skipped: SMTP not configured');
    return;
  }

  const transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: parseInt(SMTP_PORT || '587'),
    secure: SMTP_PORT === '465',
    auth: { user: SMTP_USER, pass: SMTP_PASS },
  });

  const mailOptions = {
    from: `"PJ Position Finder" <${SMTP_USER}>`,
    to: NOTIFICATION_EMAIL,
    subject: `New PJ Position found: ${position.hospital} - ${position.specialty}`,
    text: `A new PJ position matching your criteria was found!

Hospital: ${position.hospital}
City: ${position.city}
Specialty: ${position.specialty}
Accommodation: ${position.unterkunft ? 'YES' : 'NO'}
Pay: ${position.verguetung || 'Not specified'}
URL: ${position.url}

Details: ${position.details}

Contact: ${position.ansprechpartner} (${position.ansprechpartnerPosition})
Email: ${position.email}
Phone: ${position.phone}`,
    html: `
      <h2>New PJ Position Matching Your Criteria</h2>
      <p><strong>Hospital:</strong> ${position.hospital}</p>
      <p><strong>City:</strong> ${position.city}</p>
      <p><strong>Specialty:</strong> ${position.specialty}</p>
      <p><strong>Accommodation:</strong> ${position.unterkunft ? '<span style="color: green">YES</span>' : 'NO'}</p>
      <p><strong>Pay:</strong> ${position.verguetung || 'Not specified'}</p>
      <p><a href="${position.url}">View Listing</a></p>
      <hr/>
      <p><strong>Details:</strong> ${position.details}</p>
      <p><strong>Contact:</strong> ${position.ansprechpartner} (${position.ansprechpartnerPosition})</p>
      <p><strong>Email:</strong> ${position.email}</p>
      <p><strong>Phone:</strong> ${position.phone}</p>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`Notification sent for ${position.id}`);
  } catch (error) {
    console.error('Failed to send email:', error);
  }
}

// Helper for fetching with retries
async function fetchWithRetry(url: string, retries = 3, backoff = 2000): Promise<any> {
  const headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
  };

  for (let i = 0; i < retries; i++) {
    try {
      const response = await axios.get(url, {
        headers,
        timeout: 30000,
        validateStatus: (status) => status === 200,
      });
      return response;
    } catch (error: any) {
      const isLastRetry = i === retries - 1;
      const status = error.response?.status;

      if (status === 429) {
        // Rate limited - wait longer
        const wait = backoff * (i + 1) * 2;
        console.warn(`Rate limited (429) on ${url}. Waiting ${wait}ms...`);
        await new Promise(resolve => setTimeout(resolve, wait));
      } else if (status >= 500) {
        // Server error - wait and retry
        const wait = backoff * (i + 1);
        console.warn(`Server error (${status}) on ${url}. Retrying in ${wait}ms...`);
        await new Promise(resolve => setTimeout(resolve, wait));
      } else if (error.code === 'ECONNABORTED' || error.code === 'ETIMEDOUT') {
        // Timeout
        console.warn(`Timeout on ${url}. Retrying...`);
      } else if (!isLastRetry) {
        // Other errors might be transient
        const wait = backoff;
        await new Promise(resolve => setTimeout(resolve, wait));
      }

      if (isLastRetry) throw error;
    }
  }
}

// Scraper loop
async function runScraper() {
  if (scraperStatus.isRunning) return;
  scraperStatus.isRunning = true;
  scraperStatus.error = null;
  scraperStatus.currentPage = 0;
  
  const seenIdsInThisRun = new Set<string>();

  try {
    let pageUrl = START_URL;
    let pageNum = 0;
    const maxPages = 500; 

    while (pageUrl && pageNum < maxPages && scraperStatus.isRunning) {
      pageNum++;
      scraperStatus.currentPage = pageNum;
      console.log(`Scraping page ${pageNum}: ${pageUrl}`);

      try {
        const response = await fetchWithRetry(pageUrl);
        const $ = cheerio.load(response.data);
        const jobLinks: string[] = [];

        // Robust job link selector - matches standard job paths on the platform (e.g., /job/, /jobs/, /stelle/, /stellenangebote/)
        $('a[href*="/job/"], a[href*="/jobs/"], a[href*="/stelle/"], a[href*="/stellenangebote/"]').each((_, el) => {
          const href = $(el).attr('href');
          if (href) {
            const full = href.startsWith('http') ? href : `${BASE_URL}${href}`;
            // Avoid duplicates and non-job links that might be caught
            if (!jobLinks.includes(full) && !full.includes('/job-anbieter/')) {
              jobLinks.push(full);
            }
          }
        });

        console.log(`Page ${pageNum}: Found ${jobLinks.length} unique job links. Total in DB: ${positions.length}`);

        for (const jobUrl of jobLinks) {
          if (!scraperStatus.isRunning) break;

          const slug = jobUrl.split('/').filter(Boolean).pop() || '';
          seenIdsInThisRun.add(slug);

          const existingIdx = positions.findIndex(p => p.id === slug);
          if (existingIdx !== -1) {
            positions[existingIdx].lastSeen = new Date().toISOString();
            continue;
          }

          try {
            await new Promise(resolve => setTimeout(resolve, 1200 + Math.random() * 1000));
            
            const detailRes = await fetchWithRetry(jobUrl);
            const detail$ = cheerio.load(detailRes.data);
            const detailText = detail$.text();
            const bodyHtml = detail$('body').html() || '';

            const title = detail$('h1').first().text().trim();
            if (!title) {
              console.warn(`No title found for ${jobUrl}, skipping...`);
              continue;
            }
            
            let hospital = '';
            const hospitalSelectors = ['.company-name', 'h2.job-company', '.employer', 'h2', '.job-ad-company-name', '.employer-name'];
            for (const sel of hospitalSelectors) {
              const text = detail$(sel).first().text().trim();
              if (text) { hospital = text; break; }
            }
            if (!hospital) hospital = detail$('meta[property="og:site_name"]').attr('content') || title;

            let city = detail$('[itemprop="addressLocality"]').first().text().trim();
            if (!city) {
              const m = detailText.match(/(?:Stadt|Ort|Standort|in\s+der\s+(?:Stadt\s+)?)[:\s]+([A-ZÄÖÜ][a-zäöüß\-]+(?:\s[A-ZÄÖÜ][a-zäöüß\-]+)?)/);
              if (m) city = m[1].trim();
            }

            let ansprechpartner = '';
            const namePatterns = [
              /(?:Ansprechpartner\w*|Kontakt|Ihr\s+Kontakt)[:\s]+([^\n,\.]{3,60})/i,
              /((?:Prof\.|Dr\.|PD\s+Dr\.)\s+[A-ZÄÖÜ][a-zäöüß]+(?:\s+[A-ZÄÖÜ][a-zäöüß]+)?)/,
              /Sekretariat\s+([^\n,\.]{4,60})/i,
              /z\.Hd\.\s+([^\n,\.]{4,60})/i
            ];
            for (const pattern of namePatterns) {
              const m = detailText.match(pattern);
              if (m) { 
                const candidate = m[1].trim();
                const badNames = ['agb', 'datenschutz', 'gender', 'impressum', 'cookie', 'navigation', 'melden', 'merken', 'kontakt', 'bewerben', 'teilen', 'drucken', 'suchen', 'einloggen', 'registrieren', 'zurück', 'copyright', 'alle rechte'];
                if (!badNames.some(bn => candidate.toLowerCase().includes(bn))) {
                  ansprechpartner = candidate; 
                  break; 
                }
              }
            }

            const posMatch = detailText.match(/(Oberarzt|Oberärztin|Chefarzt|Chefärztin|PJ-Beauftragter?|PJ-Beauftragte|Klinikdirektor|Direktor|Personalabteilung|Koordinator\w*|Recruiting)/i);
            const positionTitle = posMatch ? posMatch[1] : '';

            const emailMatch = detailText.match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/);
            const email = emailMatch ? emailMatch[0] : '';

            const phoneMatch = detailText.match(/(?:Tel\.?|Telefon)[:\s]*((?:\+49|0)[\s\d\-/]{6,20})/i);
            const phone = phoneMatch ? phoneMatch[1].trim() : '';

            let bewerbung = '';
            const bewMatch = detailText.match(/(?:Bewerbung|bewerben\s+Sie\s+sich|Unterlagen\s+an)[:\s]+([^\n\.]{5,200})/i);
            if (bewMatch) {
              const bCand = bewMatch[1].trim();
              const badBewerbungKeywords = ['merken', 'teilen', 'print', 'drucken', 'ergebnisliste', 'zurück', 'cookie', 'impressum', 'datenschutz'];
              if (!badBewerbungKeywords.some(bk => bCand.toLowerCase().includes(bk))) {
                bewerbung = bCand;
              }
            }
            if (!bewerbung && detail$('a:contains("Bewerben"), a:contains("Apply")').length) {
              bewerbung = 'Via online portal on website';
            }

            const paras: string[] = [];
            detail$('p, div.job-description-paragraph, div.job-details').each((_, el) => {
              const t = detail$(el).text().trim();
              if (t.length > 50) paras.push(t);
            });
            const details = paras.slice(0, 3).join(' ').slice(0, 600);

            const hasAccommodation = detectUnterkunft(detailText) || detectUnterkunft(bodyHtml);
            const pay = extractVerguetung(detailText);

            const newPos: Position = {
              id: slug,
              title,
              hospital,
              city,
              url: jobUrl,
              specialty: detectSpecialty(jobUrl, title),
              unterkunft: hasAccommodation,
              verguetung: pay,
              details,
              ansprechpartner,
              ansprechpartnerPosition: positionTitle,
              email,
              phone,
              bewerbung,
              dateFound: new Date().toISOString(),
              lastSeen: new Date().toISOString(),
            };

            positions.push(newPos);
            scraperStatus.foundCount = positions.length;
            await savePositions();

            if (hasAccommodation) {
              await sendNotification(newPos);
            }
            
          } catch (err: any) {
            console.error(`Error scraping job details ${jobUrl}: ${err.message}`);
          }
        }

        // Robust Pagination
        let nextUrl = '';
        const nextRel = $('a[rel="next"]').first().attr('href');
        if (nextRel) {
          nextUrl = nextRel.startsWith('http') ? nextRel : `${BASE_URL}${nextRel}`;
        } else {
          // Fallback searching for page links
          const pageLinks = $('a.page-numbers, a.pagination-link, .pagination a');
          pageLinks.each((_, el) => {
            const pageText = $(el).text().trim();
            if (pageText === (pageNum + 1).toString() || pageText === 'Next' || pageText === 'Weiter') {
              const href = $(el).attr('href');
              if (href) {
                nextUrl = href.startsWith('http') ? href : `${BASE_URL}${href}`;
              }
            }
          });
        }

        // Second fallback: pattern-matching — only if we found jobs on this page
        if (!nextUrl && pageNum < 400 && jobLinks.length > 0) {
          // Many WordPress or similar sites use /page/N/ or ?page=N or ?p=N
          if (START_URL.includes('?')) {
            nextUrl = `${START_URL}&p=${pageNum + 1}`;
          } else {
            nextUrl = `${START_URL}page/${pageNum + 1}/`;
          }
          console.log(`Using pattern-matching fallback for pagination: ${nextUrl}`);
        } else if (!nextUrl) {
          console.log(`No next page found and no jobs on this page — stopping pagination at page ${pageNum}.`);
        }
        
        pageUrl = nextUrl;

      } catch (err: any) {
        console.error(`Critical error on page ${pageUrl}: ${err.message}`);
        scraperStatus.error = `Page ${pageNum}: ${err.message}`;
        // If the index page fails after retries, we might want to stop or log heavily
        break;
      }
    }

    // Cleanup: If we finished the scan successfully (reached the last page), 
    // we can remove positions that weren't seen in this run.
    if (!pageUrl && scraperStatus.isRunning && !scraperStatus.error) {
      const initialCount = positions.length;
      positions = positions.filter(p => seenIdsInThisRun.has(p.id));
      console.log(`Cleanup: Removed ${initialCount - positions.length} positions that are no longer listed.`);
    }

  } catch (error: any) {
    console.error('Scraper fatal error:', error);
    scraperStatus.error = error.message;
  } finally {
    scraperStatus.isRunning = false;
    scraperStatus.lastRun = new Date().toISOString();
    await savePositions();
  }
}

async function loadPositions() {
  try {
    const data = await fs.readFile(POSITIONS_FILE, 'utf-8');
    positions = JSON.parse(data);
    
    // Auto-sanitize saved entries to remove dirty parsed strings
    const badNames = ['agb', 'datenschutz', 'gender', 'impressum', 'cookie', 'navigation', 'melden', 'merken', 'kontakt', 'bewerben', 'teilen', 'drucken', 'suchen', 'einloggen', 'registrieren', 'zurück', 'copyright', 'alle rechte'];
    const badBewerbungKeywords = ['merken', 'teilen', 'print', 'drucken', 'ergebnisliste', 'zurück', 'cookie', 'impressum', 'datenschutz'];
    
    positions = positions.map(p => {
      let ans = p.ansprechpartner || '';
      if (badNames.some(bn => ans.toLowerCase().includes(bn))) {
        ans = '';
      }
      let bew = p.bewerbung || '';
      if (badBewerbungKeywords.some(bk => bew.toLowerCase().includes(bk))) {
        bew = '';
      }
      return {
        ...p,
        ansprechpartner: ans,
        bewerbung: bew
      };
    });
    
    scraperStatus.foundCount = positions.length;
  } catch (err) {
    positions = [];
  }
}

async function savePositions() {
  try {
    await fs.mkdir(DATA_DIR, { recursive: true });
    await fs.writeFile(POSITIONS_FILE, JSON.stringify(positions, null, 2));
  } catch (err) {
    console.error('Save failed:', err);
  }
}

async function startServer() {
  const app = express();
  app.use(express.json());

  await loadPositions();

  // API Routes
  app.get('/api/status', (req, res) => {
    res.json(scraperStatus);
  });

  app.get('/api/positions', (req, res) => {
    res.json(positions);
  });

  app.post('/api/scrape', (req, res) => {
    if (scraperStatus.isRunning) {
      return res.status(400).json({ message: 'Scraper already running' });
    }
    runScraper();
    res.json({ message: 'Scraper started' });
  });

  app.post('/api/stop', (req, res) => {
    scraperStatus.isRunning = false;
    res.json({ message: 'Scraper stopping' });
  });

  // File Management
  app.get('/api/files', async (req, res) => {
    try {
      await fs.mkdir(UPLOADS_DIR, { recursive: true });
      const files = await fs.readdir(UPLOADS_DIR);
      res.json(files);
    } catch (err) {
      res.status(500).json({ message: 'Failed to list files' });
    }
  });

  function getContentType(filename: string): string {
    const ext = path.extname(filename).toLowerCase();
    switch (ext) {
      case '.pdf': return 'application/pdf';
      case '.png': return 'image/png';
      case '.jpg':
      case '.jpeg': return 'image/jpeg';
      case '.doc': return 'application/msword';
      case '.docx': return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      default: return 'application/octet-stream';
    }
  }

  app.post('/api/send-email', async (req, res) => {
    const { to, subject, body } = req.body;
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ message: 'No authorization credentials' });
    }

    try {
      // 1. Get uploaded files to attach
      const attachedFiles: { name: string; buffer: Buffer }[] = [];
      try {
        await fs.mkdir(UPLOADS_DIR, { recursive: true });
        const list = await fs.readdir(UPLOADS_DIR);
        for (const file of list) {
          const filePath = path.join(UPLOADS_DIR, file);
          const stat = await fs.stat(filePath);
          if (stat.isFile()) {
            const buffer = await fs.readFile(filePath);
            // Show the original filename instead of our timestamp-prefixed filename in the email
            const cleanName = file.split('-').slice(1).join('-');
            attachedFiles.push({ name: cleanName || file, buffer });
          }
        }
      } catch (e) {
        console.error('Failed to read attachments', e);
      }

      // 2. Build MIME message
      const boundary = `PJ_APP_MIME_BOUNDARY_${Date.now()}`;
      
      const headerLines = [
        `To: ${to}`,
        `Subject: =?utf-8?B?${Buffer.from(subject).toString('base64')}?=`, // support subject special chars
        `MIME-Version: 1.0`,
        `Content-Type: multipart/mixed; boundary="${boundary}"`,
        ``,
        `--${boundary}`,
        `Content-Type: text/plain; charset="UTF-8"`,
        `Content-Transfer-Encoding: base64`,
        ``,
        Buffer.from(body).toString('base64').replace(/(.{76})/g, '$1\r\n'),
        ``
      ];

      for (const att of attachedFiles) {
        const contentType = getContentType(att.name);
        const base64Data = att.buffer.toString('base64').replace(/(.{76})/g, '$1\r\n');
        
        headerLines.push(`--${boundary}`);
        headerLines.push(`Content-Type: ${contentType}; name="${att.name}"`);
        headerLines.push(`Content-Disposition: attachment; filename="${att.name}"`);
        headerLines.push(`Content-Transfer-Encoding: base64`);
        headerLines.push(``);
        headerLines.push(base64Data);
        headerLines.push(``);
      }

      headerLines.push(`--${boundary}--`);
      const rawMIME = headerLines.join('\r\n');

      const encodedMessage = Buffer.from(rawMIME)
        .toString('base64')
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=+$/, '');

      // 3. Send email via Google Gmail API
      const response = await axios.post(
        'https://gmail.googleapis.com/gmail/v1/users/me/messages/send',
        { raw: encodedMessage },
        {
          headers: {
            'Authorization': authHeader,
            'Content-Type': 'application/json'
          }
        }
      );

      res.json({ message: 'Email sent successfully!', messageId: response.data.id });
    } catch (error: any) {
      console.error('Failed to send email:', error?.response?.data || error);
      const errMsg = error?.response?.data?.error?.message || error.message;
      res.status(500).json({ message: 'Failed to send email via Gmail: ' + errMsg });
    }
  });

  app.post('/api/upload', upload.single('file'), (req, res) => {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }
    res.json({ message: 'File uploaded', filename: req.file.filename });
  });

  app.delete('/api/files/:name', async (req, res) => {
    try {
      const filePath = path.join(UPLOADS_DIR, req.params.name);
      await fs.unlink(filePath);
      res.json({ message: 'File deleted' });
    } catch (err) {
      res.status(500).json({ message: 'Failed to delete file' });
    }
  });

  app.delete('/api/positions', async (req, res) => {
    positions = [];
    scraperStatus.foundCount = 0;
    await savePositions();
    res.json({ message: 'Positions cleared' });
  });

  app.post('/api/generate-draft', async (req, res) => {
    const { positionId, userProfile } = req.body;
    const pos = positions.find(p => p.id === positionId);
    
    if (!pos) {
      return res.status(404).json({ message: 'Position not found' });
    }

    try {
      // Get list of uploaded documents
      let docs = [];
      try {
        docs = await fs.readdir(UPLOADS_DIR);
      } catch (e) {}

      const prompt = `
        You are a medical student applying for a PJ (Praktisches Jahr) position in Germany.
        Generate a professional, polite, and enthusiastic application email (Motivation Letter style) in GERMAN.
        
        APPLICANT PROFILE:
        - Name: ${userProfile?.name || '[Mein Name]'}
        - University: ${userProfile?.university || '[Meine Universität]'}
        - Relevant Experience: ${userProfile?.experience || 'Medical Student'}
        - Specific Interest: ${userProfile?.interest || 'Clinical Internship'}
        
        POSITION DETAILS:
        - Hospital: ${pos.hospital}
        - City: ${pos.city}
        - Specialty: ${pos.specialty}
        - Contact Person: ${pos.ansprechpartner}
        - Position details: ${pos.details}
        
        ATTACHED DOCUMENTS (mention these):
        ${docs.length > 0 ? docs.map(d => `- ${d.split('-').slice(1).join('-')}`).join('\n') : '- Lebenslauf (CV)\n- Transcripts'}
        
        The email should:
        1. Address ${pos.ansprechpartner || 'the contact person'} professionally (e.g., Sehr geehrte/r Dr./Frau/Herr...).
        2. Clearly state interest in the PJ position specifically in ${pos.specialty} at ${pos.hospital}.
        3. Incorporate the applicant's background: ${userProfile?.experience || ''}.
        4. Explicitly mention that the documents listed above are attached to the email.
        5. Briefly explain why this department/hospital is attractive (based on position details).
        6. Ask for a professional meeting or a trial day (Probearbeitstag) if possible.
        7. Maintain a high professional standard (Formal German).
        8. IMPORTANT: NEVER use the word "Hospitation" in the text.
        
        Return ONLY the subject line and the email body as a JSON object with keys "subject" and "body".
      `;

      const result = await getAI().models.generateContent({
        model: "gemini-2.0-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        }
      });

      const draft = JSON.parse(result.text || '{}');
      res.json(draft);
    } catch (error: any) {
      console.error('Gemini error:', error);
      res.status(500).json({ message: 'Failed to generate draft: ' + error.message });
    }
  });

  app.post('/api/analyze-fit', async (req, res) => {
    const { positionId, userProfile } = req.body;
    const pos = positions.find(p => p.id === positionId);
    
    if (!pos) {
      return res.status(404).json({ message: 'Position not found' });
    }

    try {
      const prompt = `
        You are an expert medical career advisor in Germany. Analyze how well this medical student aligns with the clinical PJ (Praktisches Jahr) internship opening.
        
        CANDIDATE INFORMATION:
        - Name: ${userProfile?.name || '[Student]'}
        - University: ${userProfile?.university || '[Not specified]'}
        - Target Specialty / Interest: ${userProfile?.interest || 'Clinical Internship'}
        - Background / Experience: ${userProfile?.experience || 'No experience highlights provided yet.'}
        
        CLINICAL POSITION DESCRIPTION:
        - Title: ${pos.title}
        - Hospital: ${pos.hospital}
        - Specialty: ${pos.specialty}
        - City / Region: ${pos.city || 'Germany'}
        - Accommodation Benefit: ${pos.unterkunft ? 'Yes, available' : 'Not specified/None'}
        - Salary: ${pos.verguetung || 'Not specified'}
        - Details: ${pos.details}
        
        Provide a detailed, realistic, constructive match analysis in GERMAN.
        Return ONLY a JSON structured response with the following keys:
        {
          "score": (an integer between 35 and 98 based on qualifications, interest alignment, and specialties),
          "relevanceSummary": "A direct, 1-2 sentence professional overview of applicability.",
          "pros": ["Highlight 1 why they are a strong fit", "Highlight 2...", "Highlight 3..."],
          "cons": ["Potential gap 1 or restriction to be aware of", "Gap 2..."],
          "strategy": ["Letter adjustment tip 1", "Interview strategy tip 2", "Document focus 3"]
        }
      `;

      const result = await getAI().models.generateContent({
        model: "gemini-2.0-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        }
      });

      const analysis = JSON.parse(result.text || '{}');
      res.json(analysis);
    } catch (error: any) {
      console.error('Gemini analyze-fit error:', error);
      res.status(500).json({ message: 'Failed to complete listing analysis: ' + error.message });
    }
  });

  // Schedule cron job to run every day at 3 AM
  cron.schedule('0 3 * * *', () => {
    console.log('Running daily scraper job');
    runScraper();
  });

  // Vite/Static Setup
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
