import React, { useState, useEffect, useMemo } from 'react';
import { 
  Search, 
  MapPin, 
  Building2, 
  Stethoscope, 
  Euro, 
  Home, 
  RefreshCcw, 
  Play, 
  Square, 
  Mail, 
  Phone, 
  Trash2,
  ExternalLink,
  ChevronRight,
  Filter,
  CheckCircle2,
  Clock,
  AlertCircle,
  Wand2,
  X,
  Copy,
  Send,
  User,
  Settings,
  Save,
  FileText,
  TrendingUp,
  Briefcase,
  History,
  BarChart3,
  Calendar,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { initAuth, googleSignIn, logout } from './firebase';

interface UserProfile {
  name: string;
  university: string;
  experience: string;
  interest: string;
}

interface Position {
  id: string;
  title: string;
  hospital: string;
  city: string;
  url: string;
  specialty: string;
  unterkunft: boolean;
  verguetung: string | null;
  details: string;
  ansprechpartner: string;
  ansprechpartnerPosition: string;
  email: string;
  phone: string;
  bewerbung: string;
  dateFound: string;
}

interface ScraperStatus {
  isRunning: boolean;
  lastRun: string | null;
  foundCount: number;
  currentPage: number;
  error: string | null;
}

interface TrackerEntry {
  id: string;
  hospital: string;
  city: string;
  specialty: string;
  title: string;
  status: 'saved' | 'drafting' | 'applied' | 'interview' | 'offer' | 'rejected';
  notes: string;
  dateUpdated: string;
}

interface SentMailLog {
  id: string;
  recipient: string;
  hospital: string;
  specialty: string;
  subject: string;
  body: string;
  timestamp: string;
  attachments: string[];
  method?: 'api' | 'mailto' | 'gmail-web';
}

export default function App() {
  // Navigation & States
  const [activeTab, setActiveTab] = useState<'positions' | 'analytics' | 'tracker' | 'logs'>(() => {
    // Check if path is /feature to land directly on the Tracker / Advanced features dashboard
    if (window.location.pathname === '/feature' || window.location.pathname.startsWith('/feature')) {
      return 'tracker';
    }
    return 'positions';
  });

  const [positions, setPositions] = useState<Position[]>([]);
  const [status, setStatus] = useState<ScraperStatus>({
    isRunning: false,
    lastRun: null,
    foundCount: 0,
    currentPage: 0,
    error: null
  });

  const [search, setSearch] = useState('');
  const [filterUnterkunft, setFilterUnterkunft] = useState(false);
  const [selectedSpecialty, setSelectedSpecialty] = useState('All');

  // Application letter composer states
  const [draftingPos, setDraftingPos] = useState<Position | null>(null);
  const [draft, setDraft] = useState<{ subject: string; body: string } | null>(null);
  const [isDraftLoading, setIsDraftLoading] = useState(false);

  // AI Fit Analyzer states
  const [analyzingPos, setAnalyzingPos] = useState<Position | null>(null);
  const [fitAnalysis, setFitAnalysis] = useState<{
    score: number;
    relevanceSummary: string;
    pros: string[];
    cons: string[];
    strategy: string[];
  } | null>(null);
  const [isFitLoading, setIsFitLoading] = useState(false);

  // Authentications
  const [authUser, setAuthUser] = useState<any | null>(null);
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isSendingEmail, setIsSendingEmail] = useState(false);

  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('pj_profile');
    return saved ? JSON.parse(saved) : {
      name: '',
      university: '',
      experience: '',
      interest: 'PJ (Praktisches Jahr) clinical clerkship'
    };
  });
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);

  // Persistent Custom Features: Tracker & Logs
  const [tracker, setTracker] = useState<TrackerEntry[]>(() => {
    const saved = localStorage.getItem('pj_tracker_v1');
    return saved ? JSON.parse(saved) : [];
  });

  const [sentMailLogs, setSentMailLogs] = useState<SentMailLog[]>(() => {
    const saved = localStorage.getItem('pj_sent_logs');
    return saved ? JSON.parse(saved) : [];
  });

  // Fetch file attachments and scan status
  const fetchFiles = async () => {
    try {
      const res = await fetch('/api/files');
      if (res.ok) {
        const data = await res.json();
        setUploadedFiles(data);
      }
    } catch (err) {
      console.error('Failed to fetch files');
    }
  };

  const fetchData = async () => {
    try {
      const [posRes, statusRes] = await Promise.all([
        fetch('/api/positions'),
        fetch('/api/status')
      ]);
      if (posRes.ok && statusRes.ok) {
        const posData = await posRes.json();
        const statusData = await statusRes.json();
        setPositions(posData);
        setStatus(statusData);
      }
    } catch (error) {
      console.error('Failed to fetch data', error);
    }
  };

  useEffect(() => {
    fetchData();
    fetchFiles();
    const interval = setInterval(fetchData, 6000);

    // Watch for back/forward routing changes to switch tabs
    const handleLocationChange = () => {
      if (window.location.pathname === '/feature') {
        setActiveTab('tracker');
      } else {
        setActiveTab('positions');
      }
    };
    window.addEventListener('popstate', handleLocationChange);

    // Initialize Firebase Auth
    const unsubscribe = initAuth(
      (user, token) => {
        setAuthUser(user);
        setAuthToken(token);
      },
      () => {
        setAuthUser(null);
        setAuthToken(null);
      }
    );

    return () => {
      clearInterval(interval);
      window.removeEventListener('popstate', handleLocationChange);
      unsubscribe();
    };
  }, []);

  // Sync tracker to localStorage
  useEffect(() => {
    localStorage.setItem('pj_tracker_v1', JSON.stringify(tracker));
  }, [tracker]);

  // Sync logs to localStorage
  useEffect(() => {
    localStorage.setItem('pj_sent_logs', JSON.stringify(sentMailLogs));
  }, [sentMailLogs]);

  // Handle browser URL clean update on internal tab switch
  const handleTabChange = (tab: 'positions' | 'analytics' | 'tracker' | 'logs') => {
    setActiveTab(tab);
    if (tab === 'tracker') {
      window.history.pushState(null, '', '/feature');
    } else {
      window.history.pushState(null, '', '/');
    }
  };

  const handleGoogleLogin = async () => {
    setIsLoggingIn(true);
    try {
      const result = await googleSignIn();
      if (result) {
        setAuthUser(result.user);
        setAuthToken(result.accessToken);
      }
    } catch (err) {
      console.error('Login failed:', err);
      alert('Failed to connect to Google Gmail. Please verify popups are enabled and try again.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleGoogleLogout = async () => {
    try {
      await logout();
      setAuthUser(null);
      setAuthToken(null);
    } catch (err) {
      console.error('Logout failed:', err);
    }
  };

  const handleGmailSend = async () => {
    if (!draft || !draftingPos) return;
    if (!authToken) {
      await handleGoogleLogin();
      return;
    }

    const filesToAttach = uploadedFiles.map(f => f.split('-').slice(1).join('-')).join(', ');
    const attachmentsMsg = uploadedFiles.length > 0 
      ? `\n\nIncluded Attachments:\n${filesToAttach}`
      : '\n\nNo uploaded files will be attached (add documents inside your profile to attach them).';

    const confirmSend = window.confirm(
      `Send this cover letter to ${draftingPos.hospital} (${draftingPos.email}) programmatically via Gmail?${attachmentsMsg}`
    );
    if (!confirmSend) return;

    setIsSendingEmail(true);
    try {
      const res = await fetch('/api/send-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          to: draftingPos.email,
          subject: draft.subject,
          body: draft.body
         })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.message || 'Gmail transmission failed');
      }

      // Add to Gmail Sent History Logs
      const newLog: SentMailLog = {
        id: Date.now().toString(),
        recipient: draftingPos.email,
        hospital: draftingPos.hospital,
        specialty: draftingPos.specialty,
        subject: draft.subject,
        body: draft.body,
        timestamp: new Date().toISOString(),
        attachments: uploadedFiles.map(f => f.split('-').slice(1).join('-')),
        method: 'api'
      };
      setSentMailLogs(prev => [newLog, ...prev]);

      // Automatically push this position to tracking pipeline under "applied" status
      upsertToTracker(draftingPos, 'applied', 'Application letter sent programmatically via connected Gmail.');

      alert(`Your application has been successfully transmitted to ${draftingPos.hospital}! The event has been logged in your history.`);
      setDraftingPos(null);
    } catch (err: any) {
      console.error('Email transmission failed:', err);
      alert(`Could not send application email: ${err.message}`);
    } finally {
      setIsSendingEmail(false);
    }
  };

  const handleStart = async () => {
    await fetch('/api/scrape', { method: 'POST' });
    fetchData();
  };

  const handleStop = async () => {
    await fetch('/api/stop', { method: 'POST' });
    fetchData();
  };

  const handleClear = async () => {
    if (window.confirm('Delete all found listings in database? This clear cannot be undone.')) {
      await fetch('/api/positions', { method: 'DELETE' });
      fetchData();
    }
  };

  const handleGenerateDraft = async (pos: Position) => {
    setDraftingPos(pos);
    setIsDraftLoading(true);
    setDraft(null);
    try {
      const res = await fetch('/api/generate-draft', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          positionId: pos.id,
          userProfile 
        }),
      });
      if (!res.ok) throw new Error('Cover letter draft generation failed');
      const data = await res.json();
      setDraft(data);
    } catch (error) {
      console.error('Failed to generate draft', error);
      alert('Failed to generate application letter. Please verify your internet connection and try again.');
    } finally {
      setIsDraftLoading(false);
    }
  };

  const handleAnalyzeFit = async (pos: Position) => {
    setAnalyzingPos(pos);
    setIsFitLoading(true);
    setFitAnalysis(null);
    try {
      const res = await fetch('/api/analyze-fit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          positionId: pos.id,
          userProfile
        })
      });
      if (!res.ok) throw new Error('Analysis failed');
      const data = await res.json();
      setFitAnalysis(data);
    } catch (error) {
      console.error('Failed alignment analysis', error);
      alert('Failed to analyze matching score. Please try again.');
    } finally {
      setIsFitLoading(false);
    }
  };

  const handleSendDraft = (method: 'mailto' | 'gmail' = 'mailto') => {
    if (!draft || !draftingPos) return;
    
    // Log the event as manually sent
    const newLog: SentMailLog = {
      id: Date.now().toString(),
      recipient: draftingPos.email,
      hospital: draftingPos.hospital,
      specialty: draftingPos.specialty,
      subject: draft.subject,
      body: draft.body,
      timestamp: new Date().toISOString(),
      attachments: [],
      method: method === 'gmail' ? 'gmail-web' : 'mailto'
    };
    setSentMailLogs(prev => [newLog, ...prev]);
    upsertToTracker(draftingPos, 'drafting', 'Manually navigated to external mail app with draft cover letter.');

    if (method === 'gmail') {
      const url = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(draftingPos.email)}&su=${encodeURIComponent(draft.subject)}&body=${encodeURIComponent(draft.body)}`;
      window.open(url, '_blank');
    } else {
      const mailtoUrl = `mailto:${draftingPos.email}?subject=${encodeURIComponent(draft.subject)}&body=${encodeURIComponent(draft.body)}`;
      window.open(mailtoUrl, '_blank');
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('pj_profile', JSON.stringify(userProfile));
    setShowProfileModal(false);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      if (!res.ok) throw new Error('Upload failed');
      await fetchFiles();
    } catch (err) {
      alert('Failed to securely upload documents.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleDeleteFile = async (filename: string) => {
    if (!window.confirm("Permanently delete this application document from your vault?")) return;
    try {
      await fetch('/api/files/' + filename, { method: 'DELETE' });
      await fetchFiles();
    } catch (err) {
      alert('Failed to delete file');
    }
  };

  // Tracker utility operations
  const upsertToTracker = (pos: Position | { id: string; hospital: string; city: string; specialty: string; title: string }, statusVal: TrackerEntry['status'] = 'saved', defaultNotes: string = '') => {
    setTracker(prev => {
      const existing = prev.find(t => t.id === pos.id);
      if (existing) {
        return prev.map(t => t.id === pos.id ? { 
          ...t, 
          status: statusVal, 
          dateUpdated: new Date().toISOString(),
          notes: t.notes || defaultNotes
        } : t);
      }
      const newEntry: TrackerEntry = {
        id: pos.id,
        hospital: pos.hospital,
        city: pos.city || 'Germany',
        specialty: pos.specialty,
        title: pos.title,
        status: statusVal,
        notes: defaultNotes,
        dateUpdated: new Date().toISOString()
      };
      return [newEntry, ...prev];
    });
  };

  const updateTrackerNotes = (id: string, notes: string) => {
    setTracker(prev => prev.map(t => t.id === id ? { ...t, notes, dateUpdated: new Date().toISOString() } : t));
  };

  const updateTrackerStatus = (id: string, statusVal: TrackerEntry['status']) => {
    setTracker(prev => prev.map(t => t.id === id ? { ...t, status: statusVal, dateUpdated: new Date().toISOString() } : t));
  };

  const removeFromTracker = (id: string) => {
    if (window.confirm('Remove this clinical entry from your pipeline tracker?')) {
      setTracker(prev => prev.filter(t => t.id !== id));
    }
  };

  // Specialties computed map
  const specialties = useMemo(() => {
    const s = new Set(positions.map(p => p.specialty));
    return ['All', ...Array.from(s).sort()];
  }, [positions]);

  // Filters listings
  const filteredPositions = useMemo(() => {
    return positions.filter(p => {
      const matchesSearch = 
        p.hospital.toLowerCase().includes(search.toLowerCase()) ||
        p.city.toLowerCase().includes(search.toLowerCase()) ||
        p.title.toLowerCase().includes(search.toLowerCase());
      
      const matchesUnterkunft = filterUnterkunft ? p.unterkunft : true;
      const matchesSpecialty = selectedSpecialty === 'All' ? true : p.specialty === selectedSpecialty;
      
      return matchesSearch && matchesUnterkunft && matchesSpecialty;
    }).sort((a, b) => new Date(b.dateFound).getTime() - new Date(a.dateFound).getTime());
  }, [positions, search, filterUnterkunft, selectedSpecialty]);

  // Interactive Analytics Data computation for Pure SVG Charts
  const analyticsData = useMemo(() => {
    // 1. Specialty Count
    const specMap: Record<string, number> = {};
    positions.forEach(p => {
      specMap[p.specialty] = (specMap[p.specialty] || 0) + 1;
    });
    const specialtyHistogram = Object.entries(specMap)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8); // Top 8 specialties

    // 2. Lodging Availability count
    const accommodationCount = positions.filter(p => p.unterkunft).length;
    const noAccommodationCount = positions.length - accommodationCount;

    // 3. Salaries bands
    let withPayCount = 0;
    let avgEstimatedPay = 0;
    let paySum = 0;
    positions.forEach(p => {
      if (p.verguetung) {
        const salaryNum = parseInt(p.verguetung.replace(/[^\d]/g, ''));
        if (!isNaN(salaryNum)) {
          withPayCount++;
          paySum += salaryNum;
        }
      }
    });
    avgEstimatedPay = withPayCount > 0 ? Math.floor(paySum / withPayCount) : 0;

    return {
      specialtyHistogram,
      accommodationCount,
      noAccommodationCount,
      withPayCount,
      avgEstimatedPay
    };
  }, [positions]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans flex flex-col antialiased">
      {/* Dynamic Professional Header Banner */}
      <header className="h-16 bg-white border-b border-slate-200 sticky top-0 z-20 shrink-0 shadow-xs">
        <div className="max-w-[1440px] mx-auto px-8 h-full flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="bg-slate-900 w-9 h-9 flex items-center justify-center rounded-sm">
              <Stethoscope className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-baseline gap-2">
                <h1 className="text-base font-bold tracking-tight text-slate-900 leading-none">PJ POSITIONS RADAR</h1>
                <span className="font-mono text-[9px] font-bold bg-sky-50 text-sky-700 px-1.5 py-0.5 rounded-xs">GERMANY</span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">SaaS-Grade PJ clinical listings & mail dispatcher</p>
            </div>
          </div>

          {/* Premium Modular Horizontal Navigation Bar */}
          <nav className="hidden md:flex bg-slate-100 p-1 rounded-sm border border-slate-200 gap-1">
            <button 
              onClick={() => handleTabChange('positions')}
              className={`flex items-center gap-2 px-4 py-1.5 text-xs font-bold uppercase tracking-wider rounded-xs transition-all ${activeTab === 'positions' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
            >
              <Search className="w-3.5 h-3.5" />
              Scraped Positions
            </button>
            <button 
              onClick={() => handleTabChange('tracker')}
              className={`flex items-center gap-2 px-4 py-1.5 text-xs font-bold uppercase tracking-wider rounded-xs transition-all relative ${activeTab === 'tracker' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
            >
              <Briefcase className="w-3.5 h-3.5" />
              Application Tracker
              {tracker.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white font-mono text-[8px] h-4 min-w-4 px-1 rounded-full flex items-center justify-center font-bold">
                  {tracker.length}
                </span>
              )}
            </button>
            <button 
              onClick={() => handleTabChange('analytics')}
              className={`flex items-center gap-2 px-4 py-1.5 text-xs font-bold uppercase tracking-wider rounded-xs transition-all ${activeTab === 'analytics' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              Market Insights
            </button>
            <button 
              onClick={() => handleTabChange('logs')}
              className={`flex items-center gap-2 px-4 py-1.5 text-xs font-bold uppercase tracking-wider rounded-xs transition-all relative ${activeTab === 'logs' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
            >
              <History className="w-3.5 h-3.5" />
              Sent Mail History
              {sentMailLogs.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-sky-600 text-white font-mono text-[8px] h-4 min-w-4 px-1 rounded-full flex items-center justify-center font-bold">
                  {sentMailLogs.length}
                </span>
              )}
            </button>
          </nav>

          <div className="flex items-center gap-4">
            <div className="hidden lg:flex items-center gap-2.5">
              <span className={`w-2.5 h-2.5 rounded-full ${status.isRunning ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300'}`}></span>
              <span className="font-mono text-[9px] font-bold uppercase tracking-wider text-slate-500">
                {status.isRunning ? `Scanning page ${status.currentPage}...` : 'Monitoring Standby'}
              </span>
            </div>
            
            <button 
              onClick={() => setShowProfileModal(true)}
              className="flex items-center justify-center w-8 h-8 rounded-full border border-slate-200 bg-slate-50 hover:bg-slate-100 transition-colors"
              title="Applicant Profile & Documents"
            >
              <User className="w-4 h-4 text-slate-600" />
            </button>

            {status.isRunning ? (
              <button 
                onClick={handleStop}
                className="flex items-center gap-2 px-3 py-1.5 bg-red-50 text-red-700 border border-red-100 text-[10px] font-bold uppercase tracking-widest rounded-sm hover:bg-red-100 transition-colors"
                title="Force stop scraper execution"
              >
                <Square className="w-3 h-3 fill-current text-red-600" />
                Stop
              </button>
            ) : (
              <button 
                onClick={handleStart}
                className="flex items-center gap-2 px-3 py-1.5 bg-slate-900 text-white text-[10px] font-bold uppercase tracking-widest rounded-sm hover:bg-black transition-all"
                title="Trigger immediate listings update scan"
              >
                <Play className="w-3 h-3 fill-current text-white" />
                Scan Now
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Container */}
      <div className="flex-1 flex overflow-hidden w-full max-w-[1440px] mx-auto min-h-0">
        
        {/* Dynamic Mobile and Tablet Fallback Navigation for activeTab */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-slate-200 z-30 flex items-center justify-around px-4 shadow-lg">
          <button 
            onClick={() => handleTabChange('positions')}
            className={`flex flex-col items-center gap-1 ${activeTab === 'positions' ? 'text-sky-600' : 'text-slate-400'}`}
          >
            <Search className="w-5 h-5" />
            <span className="text-[9px] font-bold uppercase">Listings</span>
          </button>
          <button 
            onClick={() => handleTabChange('tracker')}
            className={`flex flex-col items-center gap-1 relative ${activeTab === 'tracker' ? 'text-sky-600' : 'text-slate-400'}`}
          >
            <Briefcase className="w-5 h-5" />
            <span className="text-[9px] font-bold uppercase font-mono">Tracker</span>
            {tracker.length > 0 && <span className="absolute top-0 right-1 bg-red-500 text-white text-[8px] h-3.5 w-3.5 rounded-full flex items-center justify-center font-bold">{tracker.length}</span>}
          </button>
          <button 
            onClick={() => handleTabChange('analytics')}
            className={`flex flex-col items-center gap-1 ${activeTab === 'analytics' ? 'text-sky-600' : 'text-slate-400'}`}
          >
            <BarChart3 className="w-5 h-5" />
            <span className="text-[9px] font-bold uppercase">Analytics</span>
          </button>
          <button 
            onClick={() => handleTabChange('logs')}
            className={`flex flex-col items-center gap-1 relative ${activeTab === 'logs' ? 'text-sky-600' : 'text-slate-400'}`}
          >
            <History className="w-5 h-5" />
            <span className="text-[9px] font-bold uppercase">Letters</span>
            {sentMailLogs.length > 0 && <span className="absolute top-0 right-1 bg-sky-600 text-white text-[8px] h-3.5 w-3.5 rounded-full flex items-center justify-center font-bold">{sentMailLogs.length}</span>}
          </button>
        </div>

        {/* Dynamic Sidebar Parameters Screen (Only for Positions view) */}
        {activeTab === 'positions' && (
          <aside className="w-80 bg-white border-r border-slate-200 p-8 flex flex-col gap-8 shrink-0 overflow-y-auto hidden lg:flex">
            <div>
              <h2 className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-4">Search & Filters</h2>
              <div className="space-y-6">
                <div className="border-l-2 border-slate-200 hover:border-sky-500 pl-4 py-1 transition-all">
                  <p className="text-[10px] text-slate-400 uppercase font-bold mb-1">Clinic Keywords</p>
                  <div className="flex items-center text-slate-400 focus-within:text-slate-800">
                    <input 
                      type="text"
                      placeholder="Hospital or city name..."
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      className="w-full text-xs font-semibold bg-transparent border-none p-0 focus:ring-0 focus:outline-none placeholder:text-slate-300 text-slate-800"
                    />
                  </div>
                </div>

                <div className="border-l-2 border-slate-200 hover:border-sky-500 pl-4 py-1 transition-all">
                  <p className="text-[10px] text-slate-400 uppercase font-bold mb-1">Specialty Division</p>
                  <select 
                    value={selectedSpecialty}
                    onChange={(e) => setSelectedSpecialty(e.target.value)}
                    className="w-full text-xs font-semibold bg-transparent border-none p-0 focus:ring-0 focus:outline-none cursor-pointer text-slate-800 pr-5"
                  >
                    {specialties.map(s => (
                      <option key={s} value={s} className="bg-white text-slate-800 text-xs font-medium">{s}</option>
                    ))}
                  </select>
                </div>

                <div className="border-l-2 border-slate-200 pl-4 py-1">
                  <p className="text-[10px] text-slate-400 uppercase font-bold mb-3">Benefits Filters</p>
                  <button 
                    onClick={() => setFilterUnterkunft(!filterUnterkunft)}
                    className={`flex items-center gap-2 text-xs font-bold uppercase tracking-wider transition-all px-2.5 py-1.5 border rounded-xs ${filterUnterkunft ? 'text-sky-700 bg-sky-50 border-sky-100 shadow-sm' : 'text-slate-400 border-slate-100 hover:text-slate-600'}`}
                  >
                    <Home className="w-3.5 h-3.5" />
                    Lodging Provided
                  </button>
                </div>
              </div>
            </div>

            <div>
              <h2 className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-4">Sync Diagnostics</h2>
              <div className="space-y-4">
                <div className={`p-4 border rounded-sm ${status.error ? 'bg-red-50 border-red-200 text-red-900' : 'bg-slate-50 border-slate-200 text-slate-800'}`}>
                  <p className="text-[9px] uppercase font-bold tracking-widest mb-1 opacity-70">Scanner Process</p>
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${status.isRunning ? 'bg-sky-500 animate-pulse' : 'bg-slate-300'}`}></span>
                    <p className="text-xs font-bold uppercase tracking-tight">
                      {status.isRunning ? `Processing Page ${status.currentPage}` : 'Engine Standing By'}
                    </p>
                  </div>
                  {status.error && (
                    <p className="text-[9px] text-red-600 bg-white p-2 border border-red-100 rounded-xs font-mono mt-2 leading-tight">
                      {status.error}
                    </p>
                  )}
                </div>

                <div className="p-4 border border-slate-200 bg-white rounded-sm space-y-2">
                  <h3 className="text-[10px] uppercase font-bold tracking-wider text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-2">
                    <Sparkles className="w-3.5 h-3.5 text-slate-400" />
                    Match Heuristics
                  </h3>
                  <div className="space-y-4 text-[10px] font-medium leading-relaxed text-slate-500">
                    <p>
                      The radar scrapes <strong className="text-slate-700 font-semibold">praktischarzt.de</strong>, matching PJ posts, extracting monthly pay and boarding terms.
                    </p>
                    <p>
                      The database maintains <strong className="text-slate-700 font-semibold">{positions.length} active listings</strong>. Expired listings are trimmed automatically.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-auto pt-6 border-t border-slate-100">
              <button 
                onClick={handleClear}
                className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-red-600 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Flush Radar Cache
              </button>
            </div>
          </aside>
        )}

        {/* Center Main Work Content */}
        <main className="flex-1 flex flex-col p-8 overflow-y-auto pb-24 md:pb-8 min-w-0">
          
          <AnimatePresence mode="wait">
            {/* VIEW 1: Scraped Positions Radar view */}
            {activeTab === 'positions' && (
              <motion.div
                key="positions"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="flex-1 flex flex-col gap-8 min-h-0"
              >
                {/* Stats cards Grid banner */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 shrink-0">
                  <div className="bg-white border border-slate-200 p-6 rounded-sm shadow-xs flex items-center justify-between hover:shadow-md transition-shadow">
                    <div>
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1 font-mono">Total Positions Found</p>
                      <p className="text-2xl font-bold text-slate-900">{status.foundCount}</p>
                    </div>
                    <div className="w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center">
                      <Briefcase className="w-4 h-4 text-slate-500" />
                    </div>
                  </div>
                  
                  <div className="bg-white border border-slate-200 p-6 rounded-sm shadow-xs flex items-center justify-between hover:shadow-md transition-shadow">
                    <div>
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1 font-mono">Lodging guaranteed</p>
                      <div className="flex items-baseline gap-2">
                        <p className="text-2xl font-bold text-slate-900">{positions.filter(p => p.unterkunft).length}</p>
                        <span className="text-xs text-emerald-600 font-bold bg-emerald-50 px-1 rounded-xs">
                          {Math.floor((positions.filter(p => p.unterkunft).length / Math.max(1, positions.length)) * 100)}%
                        </span>
                      </div>
                    </div>
                    <div className="w-10 h-10 bg-sky-50 rounded-full flex items-center justify-center">
                      <Home className="w-4 h-4 text-sky-600" />
                    </div>
                  </div>
                </div>

                {/* Main Filter elements on Mobile (hidden on desktop sidebar) */}
                <div className="grid grid-cols-1 gap-4 lg:hidden bg-white p-4 border border-slate-200 rounded-sm">
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Search Keywords</label>
                    <input 
                      type="text"
                      placeholder="e.g., Hospital or town..."
                      className="w-full bg-slate-50 border border-slate-200 p-2 text-xs rounded-xs"
                      value={search}
                      onChange={e => setSearch(e.target.value)}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col gap-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase">Specialty Type</label>
                      <select 
                        value={selectedSpecialty}
                        onChange={e => setSelectedSpecialty(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 p-2 text-xs rounded-xs"
                      >
                        {specialties.map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </div>
                    <div className="flex items-end">
                      <button 
                        onClick={() => setFilterUnterkunft(!filterUnterkunft)}
                        className={`w-full text-center px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-xs border transition-all ${filterUnterkunft ? 'bg-sky-50 text-sky-700 border-sky-100' : 'text-slate-400 border-slate-100 hover:text-slate-600'}`}
                      >
                        Accommodation ({positions.filter(p => p.unterkunft).length})
                      </button>
                    </div>
                  </div>
                </div>

                {/* Listings Workspace Area */}
                <div className="flex-1 flex flex-col min-h-0 bg-white border border-slate-200 rounded-sm shadow-xs overflow-hidden">
                  
                  {/* Table Header Row */}
                  <div className="grid grid-cols-4 bg-slate-950 text-white px-6 py-3.5 text-[10px] font-bold uppercase tracking-widest shrink-0 font-mono">
                    <div className="col-span-2">Clinical Location & Title</div>
                    <div>General Region</div>
                    <div className="text-right">Action Gateway</div>
                  </div>

                  {/* Listings Body Scroll Container */}
                  <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
                    <AnimatePresence mode="popLayout animate-fadeIn">
                      {filteredPositions.map((pos) => (
                        <div 
                          key={pos.id}
                          className="flex flex-col px-6 py-6 hover:bg-slate-50/70 transition-all group"
                        >
                          <div className="grid grid-cols-4 items-center gap-4">
                            <div className="col-span-2 pr-4">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-bold text-slate-900 text-sm group-hover:text-slate-950 tracking-tight leading-none">
                                  {pos.hospital}
                                </span>
                                <div className="flex gap-1.5 shrink-0">
                                  {pos.unterkunft && (
                                    <span className="bg-sky-50 text-sky-700 text-[9px] font-bold uppercase tracking-tight px-1.5 py-0.5 rounded-xs flex items-center gap-1 font-mono">
                                      <Home className="w-2.5 h-2.5" />
                                      LODGING
                                    </span>
                                  )}
                                  {pos.verguetung && (
                                    <span className="bg-emerald-50 text-emerald-700 text-[9px] font-bold uppercase tracking-tight px-1.5 py-0.5 rounded-xs flex items-center gap-1 font-mono">
                                      {pos.verguetung}
                                    </span>
                                  )}
                                </div>
                              </div>
                              <div className="flex items-center gap-3 mt-1.5">
                                <span className="px-2 py-0.5 bg-slate-900 text-white text-[9px] font-bold uppercase tracking-tight font-mono rounded-xs">
                                  {pos.specialty}
                                </span>
                                <span className="text-xs font-semibold text-slate-500 truncate max-w-xs">{pos.title}</span>
                              </div>
                            </div>
                            
                            <div className="text-slate-600 font-bold text-xs flex items-center gap-1.5">
                              <MapPin className="w-3.5 h-3.5 text-slate-400" />
                              {pos.city || "Clinical Headquarters"}
                            </div>

                            <div className="text-right flex items-center justify-end gap-2.5">
                              {/* Anchor listing link */}
                              <a 
                                href={pos.url} 
                                target="_blank" 
                                rel="noreferrer" 
                                className="h-8 w-8 rounded-full border border-slate-200 bg-white flex items-center justify-center text-slate-400 hover:text-sky-600 hover:border-sky-300 transition-colors shadow-xs"
                                title="Open original vacancy posting details"
                              >
                                <ExternalLink className="w-4 h-4" />
                              </a>

                              {/* Save/Track Button */}
                              <button
                                onClick={() => {
                                  upsertToTracker(pos, 'saved', 'Manually saved from medical radar.');
                                  alert(`Successfully added ${pos.hospital} to your active Application Pipeline.`);
                                }}
                                className="h-8 px-3 rounded-full border border-slate-200 bg-white hover:bg-slate-50 text-slate-500 hover:text-slate-900 transition-all text-[10px] font-bold uppercase tracking-widest shadow-xs flex items-center gap-1.5"
                                title="Add position to personal applications tracker pipeline"
                              >
                                <Briefcase className="w-3.5 h-3.5" />
                                Save
                              </button>
                            </div>
                          </div>

                          {/* Extra contextual detail block */}
                          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-50 border border-slate-100/80 p-5 rounded-xs">
                            <div className="space-y-4">
                              <div>
                                <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2 font-mono">Detailed Requirements & Description</h4>
                                <p className="text-xs text-slate-600 leading-relaxed max-h-24 overflow-y-auto pr-2">
                                  {pos.details || 'Scraper finished successfully, but details description is empty. Check live portal listing.'}
                                </p>
                              </div>
                              {/* Contact section */}
                              <div>
                                <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-1.5 font-mono">Authorized Contact Desk</h4>
                                <div className="flex flex-col gap-2">
                                  <p className="text-xs font-bold text-slate-700">
                                    {pos.ansprechpartner || "Clinical Secretariat / General Clerk"} 
                                    {pos.ansprechpartnerPosition && <span className="text-[10px] font-normal text-slate-400 ml-1.5">({pos.ansprechpartnerPosition})</span>}
                                  </p>
                                  <div className="flex flex-wrap gap-4 text-xs font-semibold">
                                    {pos.email && (
                                      <a href={`mailto:${pos.email}`} className="text-sky-600 hover:underline flex items-center gap-1">
                                        <Mail className="w-3.5 h-3.5" />
                                        {pos.email}
                                      </a>
                                    )}
                                    {pos.phone && (
                                      <span className="text-slate-500 flex items-center gap-1 cursor-pointer" onClick={() => navigator.clipboard.writeText(pos.phone)}>
                                        <Phone className="w-3.5 h-3.5" />
                                        {pos.phone}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="flex flex-col justify-between border-t md:border-t-0 md:border-l border-slate-200/60 md:pl-6 pt-4 md:pt-0">
                              <div>
                                <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-2 font-mono">Bewerbung / Apply Guidelines</h4>
                                <p className="text-xs text-slate-600 leading-relaxed italic pr-2 font-medium">
                                  {pos.bewerbung || "Review standard requirements by clicking web link to access recruiter's application interface."}
                                </p>
                              </div>

                              {/* Interactive Action buttons */}
                              <div className="mt-4 flex flex-wrap items-center gap-3">
                                {/* AI Match Analyser Button */}
                                <button 
                                  onClick={() => handleAnalyzeFit(pos)}
                                  className="px-3 py-1.5 bg-slate-900 hover:bg-black text-white text-[9px] font-bold uppercase tracking-widest rounded-xs flex items-center gap-1.5 shadow-sm transition-all"
                                >
                                  <Sparkles className="w-3.5 h-3.5 text-sky-400 animate-pulse" />
                                  Profile Match Check
                                </button>

                                {/* Letter generate Button */}
                                <button 
                                  onClick={() => handleGenerateDraft(pos)}
                                  className="px-3 py-1.5 bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-100 text-[9px] font-bold uppercase tracking-widest rounded-xs flex items-center gap-1.5 transition-all"
                                >
                                  <Wand2 className="w-3.5 h-3.5" />
                                  Write Cover Letter
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </AnimatePresence>

                    {filteredPositions.length === 0 && (
                      <div className="py-24 text-center text-slate-400 flex flex-col items-center justify-center">
                        <AlertCircle className="w-10 h-10 mb-4 opacity-30 text-slate-400 animate-bounce" />
                        <h4 className="text-xs font-bold uppercase tracking-[0.2em]">No Clinicial matches meet criteria</h4>
                        <p className="text-[10px] text-slate-400 mt-2 font-medium">Adjust search keywords, filter rules, or expand specialities.</p>
                      </div>
                    )}
                  </div>

                  {/* Feed footer info */}
                  <div className="h-12 bg-slate-50 border-t border-slate-200 px-6 flex items-center justify-between shrink-0 font-medium text-[10px] tracking-wider text-slate-500 uppercase font-mono">
                    <span>
                      Matching {filteredPositions.length} of {positions.length} active listings on server
                    </span>
                    <span className="text-[9px] bg-slate-200 text-slate-700 font-bold px-2 py-0.5 rounded-xs">
                      REFRESH EVERY 6S
                    </span>
                  </div>
                </div>
              </motion.div>
            )}

            {/* VIEW 2: Persist Pipeline Tracker board section */}
            {activeTab === 'tracker' && (
              <motion.div
                key="tracker"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="flex-1 flex flex-col gap-6"
              >
                <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-5 shrink-0">
                  <div>
                    <h2 className="text-xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
                      <Briefcase className="w-5 h-5 text-slate-700" />
                      APPLICATION PIPELINE TRACKER
                    </h2>
                    <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                      Drag-and-select tracker for clinical clerkships in Germany. Automatically stored locally inside sandbox container.
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[9px] font-bold bg-slate-100 border border-slate-200 px-2.5 py-1.5 text-slate-600 rounded-sm">
                      ACT RECORD COUNT: <strong className="text-slate-900">{tracker.length}</strong>
                    </span>
                  </div>
                </div>

                {/* Pipeline column grid */}
                <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-6 overflow-y-auto">
                  
                  {/* Column 1: Saved / Interested Matches */}
                  <div className="bg-slate-100/50 border border-slate-200 p-4 rounded-sm flex flex-col gap-4 min-h-[400px]">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2.5 shrink-0">
                      <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 font-mono">
                        <span className="w-2 h-2 rounded-full bg-slate-400"></span>
                        Favorites ({tracker.filter(t => t.status === 'saved' || t.status === 'drafting').length})
                      </h4>
                    </div>

                    <div className="flex-1 overflow-y-auto space-y-4">
                      {tracker.filter(t => t.status === 'saved' || t.status === 'drafting').map(t => (
                        <div key={t.id} className="bg-white border border-slate-200 p-4 rounded-sm shadow-xs hover:shadow-md transition-all relative group text-left">
                          <button 
                            onClick={() => removeFromTracker(t.id)}
                            className="absolute top-2 right-2 p-1.5 text-slate-400 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                            title="Remove from tracking"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                          
                          <div className="flex items-start gap-1 mb-1 pr-6">
                            <h5 className="font-bold text-slate-900 text-xs leading-tight tracking-tight">{t.hospital}</h5>
                          </div>
                          
                          <div className="flex items-center gap-2 mt-1 mb-3">
                            <span className="px-1.5 py-0.5 bg-slate-100 text-[8px] font-bold text-slate-500 uppercase tracking-tight rounded-xs">{t.specialty}</span>
                            <span className="text-[10px] text-slate-400 font-medium">{t.city || 'Germany'}</span>
                          </div>

                          {/* Notes field */}
                          <div className="space-y-1.5 border-t border-slate-100 pt-3">
                            <label className="text-[8px] font-bold text-slate-400 uppercase tracking-widest block font-mono">Custom Notes</label>
                            <textarea 
                              value={t.notes}
                              onChange={e => updateTrackerNotes(t.id, e.target.value)}
                              placeholder="e.g. Needs transcript submission by next Friday..."
                              className="w-full bg-slate-50 border border-slate-100 hover:border-slate-200 p-2 text-[10px] rounded-xs focus:ring-1 focus:ring-sky-400 focus:outline-none focus:bg-white transition-all text-slate-600 font-medium resize-none"
                              rows={2}
                            />
                          </div>

                          {/* Controls to push status */}
                          <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-3 text-[10px] font-bold uppercase tracking-widest">
                            <span className="text-slate-400 font-mono text-[8px]">Pip. Move</span>
                            <div className="flex gap-2">
                              <button 
                                onClick={() => updateTrackerStatus(t.id, 'applied')}
                                className="text-sky-600 hover:underline hover:text-sky-700"
                              >
                                [Mark Applied]
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                      {tracker.filter(t => t.status === 'saved' || t.status === 'drafting').length === 0 && (
                        <p className="text-[10px] text-slate-400 italic text-center py-8">No favorited listings matching.</p>
                      )}
                    </div>
                  </div>

                  {/* Column 2: Applied / Message Sent */}
                  <div className="bg-slate-100/50 border border-slate-200 p-4 rounded-sm flex flex-col gap-4 min-h-[400px]">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2.5 shrink-0">
                      <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 font-mono">
                        <span className="w-2 h-2 rounded-full bg-sky-500"></span>
                        Applied / Sent ({tracker.filter(t => t.status === 'applied').length})
                      </h4>
                    </div>

                    <div className="flex-1 overflow-y-auto space-y-4">
                      {tracker.filter(t => t.status === 'applied').map(t => (
                        <div key={t.id} className="bg-white border border-slate-200 p-4 rounded-sm shadow-xs hover:shadow-md transition-all relative group text-left">
                          <button 
                            onClick={() => removeFromTracker(t.id)}
                            className="absolute top-2 right-2 p-1.5 text-slate-400 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                            title="Remove from tracking"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                          
                          <div className="flex items-start gap-1 mb-1 pr-6">
                            <h5 className="font-bold text-slate-900 text-xs leading-tight tracking-tight">{t.hospital}</h5>
                          </div>
                          
                          <div className="flex items-center gap-2 mt-1 mb-3">
                            <span className="px-1.5 py-0.5 bg-sky-50 text-sky-700 text-[8px] font-bold text-cyan-800 uppercase tracking-tight rounded-xs">{t.specialty}</span>
                            <span className="text-[10px] text-slate-400 font-medium">{t.city || 'Germany'}</span>
                          </div>

                          {/* Notes field */}
                          <div className="space-y-1.5 border-t border-slate-100 pt-3">
                            <label className="text-[8px] font-bold text-slate-400 uppercase tracking-widest block font-mono">Custom Notes</label>
                            <textarea 
                              value={t.notes}
                              onChange={e => updateTrackerNotes(t.id, e.target.value)}
                              placeholder="..."
                              className="w-full bg-slate-50 border border-slate-100 hover:border-slate-200 p-2 text-[10px] rounded-xs focus:ring-1 focus:ring-sky-400 focus:outline-none focus:bg-white transition-all text-slate-600 font-medium resize-none"
                              rows={2}
                            />
                          </div>

                          {/* Status workflow shift */}
                          <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-3 text-[10px] font-bold uppercase tracking-widest">
                            <button 
                              onClick={() => updateTrackerStatus(t.id, 'saved')}
                              className="text-slate-400 hover:text-slate-700 font-mono text-[8px]"
                            >
                              ← Back
                            </button>
                            <div className="flex gap-2">
                              <button 
                                onClick={() => updateTrackerStatus(t.id, 'interview')}
                                className="text-emerald-600 hover:underline hover:text-emerald-700"
                              >
                                [Interviewing]
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                      {tracker.filter(t => t.status === 'applied').length === 0 && (
                        <p className="text-[10px] text-slate-400 italic text-center py-8">No applications registered currently.</p>
                      )}
                    </div>
                  </div>

                  {/* Column 3: Response / Interviews */}
                  <div className="bg-slate-100/50 border border-slate-200 p-4 rounded-sm flex flex-col gap-4 min-h-[400px]">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2.5 shrink-0">
                      <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 font-mono">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                        Outcome / Results ({tracker.filter(t => t.status === 'interview' || t.status === 'offer' || t.status === 'rejected').length})
                      </h4>
                    </div>

                    <div className="flex-1 overflow-y-auto space-y-4">
                      {tracker.filter(t => t.status === 'interview' || t.status === 'offer' || t.status === 'rejected').map(t => (
                        <div key={t.id} className={`bg-white border p-4 rounded-sm shadow-xs hover:shadow-md transition-all relative group text-left ${t.status === 'offer' ? 'border-emerald-300 bg-emerald-50/10' : (t.status === 'rejected' ? 'border-red-200 bg-red-50/5' : 'border-slate-200')}`}>
                          <button 
                            onClick={() => removeFromTracker(t.id)}
                            className="absolute top-2 right-2 p-1.5 text-slate-400 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                            title="Remove from tracking"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                          
                          <div className="flex items-start gap-1 pr-6 leading-none">
                            <h5 className="font-bold text-slate-900 text-xs leading-tight tracking-tight">{t.hospital}</h5>
                          </div>
                          
                          <div className="flex items-center gap-2 mt-1 mb-3">
                            <span className="px-1.5 py-0.5 bg-slate-100 text-[8px] font-bold text-slate-500 uppercase tracking-tight rounded-xs">{t.specialty}</span>
                            <span className={`px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-tight rounded-xs ${t.status === 'offer' ? 'bg-emerald-100 text-emerald-800' : (t.status === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-orange-100 text-orange-850')}`}>
                              {t.status}
                            </span>
                          </div>

                          {/* Notes field */}
                          <div className="space-y-1.5 border-t border-slate-100 pt-3">
                            <label className="text-[8px] font-bold text-slate-400 uppercase tracking-widest block font-mono">Diary Notes / Reminders</label>
                            <textarea 
                              value={t.notes}
                              onChange={e => updateTrackerNotes(t.id, e.target.value)}
                              placeholder="..."
                              className="w-full bg-slate-50 border border-slate-100 hover:border-slate-200 p-2 text-[10px] rounded-xs focus:ring-1 focus:ring-sky-400 focus:outline-none focus:bg-white transition-all text-slate-600 font-medium resize-none"
                              rows={2}
                            />
                          </div>

                          {/* Trigger state changes */}
                          <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-3 text-[10px] font-bold uppercase tracking-widest">
                            <button 
                              onClick={() => updateTrackerStatus(t.id, 'applied')}
                              className="text-slate-400 hover:text-slate-700 font-mono text-[8px]"
                            >
                              ← Revert
                            </button>
                            <div className="flex gap-2">
                              {t.status !== 'offer' && (
                                <button 
                                  onClick={() => updateTrackerStatus(t.id, 'offer')}
                                  className="text-emerald-600 hover:underline hover:text-emerald-700"
                                >
                                  [My Offer 🎉]
                                </button>
                              )}
                              {t.status !== 'rejected' && (
                                <button 
                                  onClick={() => updateTrackerStatus(t.id, 'rejected')}
                                  className="text-slate-400 hover:text-red-500 hover:underline"
                                >
                                  [Declined]
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                      {tracker.filter(t => t.status === 'interview' || t.status === 'offer' || t.status === 'rejected').length === 0 && (
                        <p className="text-[10px] text-slate-400 italic text-center py-8">Outcome records empty.</p>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* VIEW 3: Interactive Market Analytics (SVG Chart widgets) */}
            {activeTab === 'analytics' && (
              <motion.div
                key="analytics"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="flex-1 flex flex-col gap-8 text-left"
              >
                <div>
                  <h2 className="text-xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-slate-700" />
                    CLINICAL MARKET INSIGHTS
                  </h2>
                  <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                    Live telemetry extracted directly from our database of scraped German hospital listings.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Chart widget 1: Specialty Demand */}
                  <div className="bg-white border border-slate-200 p-6 rounded-sm shadow-xs">
                    <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4 font-mono pb-2 border-b border-slate-100">
                      Job Vacancy Distribution by Clinical Specialty (Top 8)
                    </h3>
                    
                    <div className="space-y-4">
                      {analyticsData.specialtyHistogram.map((item, index) => {
                        const total = positions.length || 1;
                        const pct = Math.floor((item.count / total) * 100);
                        return (
                          <div key={item.name} className="space-y-1">
                            <div className="flex items-center justify-between text-xs font-semibold">
                              <span className="text-slate-800">{item.name}</span>
                              <span className="text-slate-400 font-mono font-bold text-[10px]">
                                {item.count} posts ({pct}%)
                              </span>
                            </div>
                            <div className="h-2 bg-slate-100 overflow-hidden rounded-full">
                              <div 
                                className="h-full bg-slate-900 rounded-full transition-all duration-1000" 
                                style={{ width: `${pct}%` }}
                              ></div>
                            </div>
                          </div>
                        );
                      })}
                      {analyticsData.specialtyHistogram.length === 0 && (
                        <p className="text-[10px] text-slate-400 italic text-center py-8">Start the scraper to compile market metrics!</p>
                      )}
                    </div>
                  </div>

                  {/* Chart widget 2: Benefits distribution & Pay segments */}
                  <div className="space-y-8 flex flex-col justify-between">
                    {/* Ring Ratio circle */}
                    <div className="bg-white border border-slate-200 p-6 rounded-sm shadow-xs flex-1 flex flex-col justify-between">
                      <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4 font-mono pb-2 border-b border-slate-100">
                        Accommodation Benefit Ratio
                      </h3>
                      
                      <div className="flex flex-col sm:flex-row items-center justify-around gap-4 flex-1">
                        {/* Custom visual ring chart in Pure Vector SVG */}
                        <div className="relative w-32 h-32 shrink-0">
                          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                            <circle cx="18" cy="18" r="15.915" fill="none" stroke="#f1f5f9" strokeWidth="3.5" />
                            {positions.length > 0 && (
                              <circle 
                                cx="18" 
                                cy="18" 
                                r="15.915" 
                                fill="none" 
                                stroke="#0284c7" 
                                strokeWidth="3.5" 
                                strokeDasharray={`${(analyticsData.accommodationCount / positions.length) * 100} ${100 - (analyticsData.accommodationCount / positions.length) * 100}`} 
                                strokeDashoffset="0"
                              />
                            )}
                          </svg>
                          <div className="absolute inset-0 flex flex-col items-center justify-center font-mono text-[10px]">
                            <span className="font-bold text-base text-slate-900 leading-none">
                              {positions.length > 0 ? Math.floor((analyticsData.accommodationCount / positions.length) * 100) : 0}%
                            </span>
                            <span className="text-[8px] uppercase text-slate-400 font-bold mt-1">Free Flat</span>
                          </div>
                        </div>

                        {/* Chart Legends */}
                        <div className="space-y-3 font-semibold text-xs text-slate-600 min-w-44 text-left">
                          <div className="flex items-center gap-3">
                            <span className="w-3 h-3 bg-sky-600 shrink-0"></span>
                            <div>
                              <p className="font-bold text-slate-900">{analyticsData.accommodationCount} listings</p>
                              <p className="text-[9px] text-slate-400">Lodging is guaranteed</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="w-3 h-3 bg-slate-200 shrink-0"></span>
                            <div>
                              <p className="font-bold text-slate-900">{analyticsData.noAccommodationCount} listings</p>
                              <p className="text-[9px] text-slate-400">Housing not specified / none</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Chart widget 3: Application Tracker stats Funnel */}
                    <div className="bg-white border border-slate-200 p-6 rounded-sm shadow-xs text-left">
                      <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4 font-mono pb-2 border-b border-slate-100">
                        My Personal Pipeline Conversion Funnel
                      </h3>
                      
                      <div className="grid grid-cols-4 gap-4 text-center">
                        <div className="space-y-1">
                          <p className="text-lg font-bold text-slate-900">{tracker.filter(t => t.status === 'saved').length}</p>
                          <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider font-mono">Saved</p>
                        </div>
                        <div className="space-y-1 border-l border-slate-100">
                          <p className="text-lg font-bold text-sky-600">{tracker.filter(t => t.status === 'applied').length}</p>
                          <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider font-mono">Applied</p>
                        </div>
                        <div className="space-y-1 border-l border-slate-100">
                          <p className="text-lg font-bold text-orange-600">{tracker.filter(t => t.status === 'interview').length}</p>
                          <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider font-mono">Interview</p>
                        </div>
                        <div className="space-y-1 border-l border-slate-100">
                          <p className="text-lg font-bold text-emerald-600">{tracker.filter(t => t.status === 'offer').length}</p>
                          <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider font-mono">Matched</p>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
              </motion.div>
            )}

            {/* VIEW 4: Programmatic Mail logs */}
            {activeTab === 'logs' && (
              <motion.div
                key="logs"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="flex-1 flex flex-col gap-6"
              >
                <div className="flex items-center justify-between border-b border-slate-200 pb-5 shrink-0">
                  <div>
                    <h2 className="text-xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
                      <History className="w-5 h-5 text-slate-700" />
                      PROGRAMMATIC GMAIL SEND HISTORY LOGS
                    </h2>
                    <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                      Complete, secure vault recording every cover letter generated and sent from this browser to recruiters.
                    </p>
                  </div>

                  <button 
                    onClick={() => {
                      if (window.confirm('Delete sent logs?')) {
                        setSentMailLogs([]);
                      }
                    }}
                    className="text-[10px] font-bold text-slate-400 hover:text-red-500 uppercase tracking-widest flex items-center gap-1.5"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Clear Letters Log
                  </button>
                </div>

                <div className="flex-1 bg-white border border-slate-200 rounded-sm overflow-hidden flex flex-col min-h-[300px]">
                  {/* Table metadata log */}
                  <div className="grid grid-cols-4 bg-slate-950 text-white px-6 py-3.5 text-[10px] tracking-widest font-bold uppercase shrink-0 font-mono text-left">
                    <div className="col-span-2">Clinical Recipient & Date</div>
                    <div>Sent Subject Line</div>
                    <div className="text-right">Dispatch Status</div>
                  </div>

                  <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
                    {sentMailLogs.map(log => (
                      <div key={log.id} className="p-6 hover:bg-slate-50 transition-colors text-left flex flex-col gap-3">
                        <div className="grid grid-cols-4 items-center gap-4">
                          <div className="col-span-2">
                            <p className="font-bold text-slate-900 text-sm tracking-tight">{log.hospital}</p>
                            <p className="text-xs text-sky-600 font-semibold">{log.recipient}</p>
                            <p className="text-[10px] text-slate-400 mt-1 font-mono font-medium">
                              Sent At: {new Date(log.timestamp).toLocaleDateString()} at {new Date(log.timestamp).toLocaleTimeString([], { hour12: false })}
                            </p>
                          </div>
                          <div className="text-xs font-semibold text-slate-600 truncate pr-4">{log.subject}</div>
                          <div className="text-right flex flex-col items-end gap-1.5">
                            {log.method === 'api' ? (
                              <span className="bg-emerald-50 text-emerald-700 text-[10px] px-2.5 py-1 rounded-sm font-bold uppercase font-mono tracking-tight flex items-center gap-1.5 border border-emerald-100 shadow-xs">
                                <Send className="w-3.5 h-3.5 text-emerald-600" />
                                Sent via API
                              </span>
                            ) : (
                              <span className="bg-amber-50 text-amber-700 text-[10px] px-2.5 py-1 rounded-sm font-bold uppercase font-mono tracking-tight flex items-center gap-1.5 border border-amber-100 shadow-xs" title="Opened pre-filled draft. You must click send manually inside the external window.">
                                <FileText className="w-3.5 h-3.5 text-amber-600" />
                                External Draft
                              </span>
                            )}
                            {log.method !== 'api' && (
                              <span className="text-[9px] text-amber-600 font-semibold italic text-right leading-none max-w-[200px]">
                                Manual action required to transmit
                              </span>
                            )}
                            {log.attachments.length > 0 && (
                              <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider font-mono">
                                {log.attachments.length} attachment files
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Inline draft detail previewer */}
                        <details className="mt-2 text-slate-600">
                          <summary className="text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-slate-700 cursor-pointer focus:outline-none">
                            [Display Email Transcript Content]
                          </summary>
                          <div className="bg-slate-50 border border-slate-100 p-5 rounded-xs mt-3 text-xs leading-relaxed max-h-40 overflow-y-auto whitespace-pre-wrap font-mono select-all">
                            {log.body}
                          </div>
                        </details>
                      </div>
                    ))}
                    {sentMailLogs.length === 0 && (
                      <div className="py-20 text-center text-slate-400 flex flex-col items-center justify-center">
                        <History className="w-8 h-8 opacity-20 mb-3" />
                        <p className="text-[10px] font-bold uppercase tracking-widest">Sent correspondence folder is currently empty.</p>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}

          </AnimatePresence>

        </main>
      </div>

      {/* Dynamic Privacy AES Footer Bar */}
      <footer className="h-8 bg-slate-950 flex items-center px-8 justify-between shrink-0 z-10 font-mono text-[9px] text-slate-500 font-bold uppercase tracking-wider border-t border-slate-900">
        <div className="flex gap-6 items-center">
          <span>
            ENVIRONMENT: <span className="text-sky-400">NODE.JS COMPILED RUNTIME</span>
          </span>
          <span className="hidden sm:inline">
            RADAR AGENT DATA INTEGRATION: <span className="text-emerald-500">PRAKTISCHARZT.DE</span>
          </span>
        </div>
        <div>
          <span>
            {status.isRunning ? 'Scraper stream: ACTIVE ENGAGED' : 'Scraper stream: OFFLINE IDLE'}
          </span>
        </div>
      </footer>

      {/* MODAL 1: Covers letter composer container */}
      <AnimatePresence>
        {draftingPos && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 text-left"
          >
            <motion.div 
              initial={{ scale: 0.96, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.96, opacity: 0, y: 15 }}
              className="bg-white w-full max-w-2xl shadow-xl rounded-sm overflow-hidden flex flex-col h-[650px]"
            >
              <div className="p-6 border-b border-slate-100 bg-slate-50/80 flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-widest flex items-center gap-1.5 font-mono">
                    <Wand2 className="w-4 h-4 text-slate-700" />
                    AI APPLICATION COVER LETTER DRAFTER
                  </h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter mt-1">Clerkship at {draftingPos.hospital}</p>
                </div>
                <button 
                  onClick={() => setDraftingPos(null)}
                  className="p-1.5 hover:bg-slate-100 rounded-full transition-colors focus:ring-1 focus:ring-slate-300"
                >
                  <X className="w-4 h-4 text-slate-400" />
                </button>
              </div>

              {/* Composition Body Area */}
              <div className="flex-1 overflow-y-auto p-8 flex flex-col bg-white">
                {isDraftLoading ? (
                  <div className="flex-1 flex flex-col items-center justify-center text-slate-400 gap-4">
                    <RefreshCcw className="w-7 h-7 animate-spin text-slate-900" />
                    <p className="text-[10px] font-bold uppercase tracking-widest animate-pulse font-mono">DRAFTING COVER LETTER IN CLINICAL DEUTSCH...</p>
                  </div>
                ) : draft ? (
                  <div className="flex-1 flex flex-col gap-6 min-h-0">
                    <div>
                      <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5 font-mono">Email Subject</label>
                      <input 
                        type="text"
                        className="w-full bg-slate-50 p-2.5 border border-slate-200 text-xs font-bold text-slate-800 rounded-xs focus:ring-1 focus:ring-slate-400"
                        value={draft.subject}
                        onChange={e => setDraft(prev => prev ? { ...prev, subject: e.target.value } : null)}
                      />
                    </div>
                    <div className="flex-1 flex flex-col min-h-0">
                      <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5 font-mono">Motivation Details Transcript</label>
                      <textarea 
                        className="flex-1 bg-slate-50 p-6 border border-slate-200 text-xs leading-relaxed text-slate-700 font-semibold rounded-xs focus:outline-none focus:border-slate-400 transition-colors resize-none font-mono focus:bg-white overflow-y-auto"
                        value={draft.body}
                        onChange={(e) => setDraft(prev => prev ? { ...prev, body: e.target.value } : null)}
                      />
                    </div>
                  </div>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center text-slate-400">
                    <AlertCircle className="w-8 h-8 mb-2 opacity-20" />
                    <p className="text-xs">Preparation failure. Is Gemini API configured?</p>
                  </div>
                )}
              </div>

              {/* Modal controls footer */}
              <div className="p-6 bg-slate-50 border-t border-slate-100 flex flex-col gap-4 shrink-0">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div className="flex gap-2">
                    <button 
                      type="button"
                      disabled={isDraftLoading || !draft}
                      onClick={() => handleSendDraft('mailto')}
                      className="flex items-center gap-2 px-3 py-2 border border-slate-200 text-slate-600 hover:text-slate-900 bg-white text-[10px] font-bold uppercase tracking-widest transition-colors rounded-xs disabled:opacity-50 font-mono shadow-xs"
                      title="Open in external system client"
                    >
                      <Mail className="w-3.5 h-3.5" />
                      Client Mailto
                    </button>
                    <button 
                      type="button"
                      disabled={isDraftLoading || !draft}
                      onClick={() => handleSendDraft('gmail')}
                      className="flex items-center gap-2 px-3 py-2 border border-slate-200 text-slate-600 hover:text-slate-900 bg-white text-[10px] font-bold uppercase tracking-widest transition-colors rounded-xs disabled:opacity-50 font-mono shadow-xs"
                      title="Navigate directly to web draft"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      Gmail Browser
                    </button>
                  </div>

                  {authToken ? (
                    <button 
                      type="button"
                      disabled={isDraftLoading || !draft || isSendingEmail}
                      onClick={handleGmailSend}
                      className="flex items-center gap-2 px-6 py-2 bg-slate-950 text-white hover:bg-black text-[10px] font-bold uppercase tracking-widest transition-all rounded-xs disabled:opacity-50 shadow-sm"
                    >
                      {isSendingEmail ? (
                        <>
                          <RefreshCcw className="w-3.5 h-3.5 animate-spin" />
                          DISPATCHING EMAIL VIA SERVER...
                        </>
                      ) : (
                        <>
                          <Send className="w-3.5 h-3.5" />
                          Send Programmatically via Gmail API ({uploadedFiles.length} files attached)
                        </>
                      )}
                    </button>
                  ) : (
                    <button 
                      type="button"
                      disabled={isLoggingIn || isDraftLoading || !draft}
                      onClick={handleGoogleLogin}
                      className="flex items-center gap-2 px-6 py-2 bg-slate-900 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-black transition-all rounded-xs disabled:opacity-50 shadow-sm font-mono"
                    >
                      {isLoggingIn ? (
                        <>
                          <RefreshCcw className="w-3.5 h-3.5 animate-spin" />
                          CONNECTING GMAIL AUTH...
                        </>
                      ) : (
                        <>
                          <svg className="w-3.5 h-3.5 mr-1" viewBox="0 0 48 48">
                            <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                            <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                            <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                            <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                          </svg>
                          Connect Gmail to Attach CV
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* MODAL 2: Profile configuration & attachments upload vault */}
      <AnimatePresence>
        {showProfileModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 text-left font-semibold"
          >
            <motion.div 
              initial={{ scale: 0.96, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.96, opacity: 0, y: 15 }}
              className="bg-white w-full max-w-lg shadow-xl rounded-sm overflow-hidden flex flex-col max-h-[90vh]"
            >
              <div className="p-6 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 bg-slate-900 flex items-center justify-center rounded-sm">
                    <Settings className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 uppercase tracking-widest font-mono">APPLICANT SECURE PROFILE</h3>
                    <p className="text-[9px] text-slate-400 font-bold uppercase tracking-tight mt-0.5">Parameters for personalized AI correspondence</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowProfileModal(false)}
                  className="p-1.5 hover:bg-slate-100 rounded-full transition-colors focus:ring-1 focus:ring-slate-350"
                >
                  <X className="w-4 h-4 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleSaveProfile} className="p-6 overflow-y-auto space-y-6">
                <div>
                  <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5 font-mono">Full Name</label>
                  <input 
                    required
                    type="text"
                    value={userProfile.name}
                    onChange={e => setUserProfile({...userProfile, name: e.target.value})}
                    placeholder="e.g. Elena Schmidt"
                    className="w-full bg-slate-50 border border-slate-200 p-2.5 text-xs font-bold focus:ring-1 focus:ring-slate-900 focus:outline-none rounded-xs transition-all tracking-tight"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5 font-mono">School / University</label>
                    <input 
                      type="text"
                      value={userProfile.university}
                      onChange={e => setUserProfile({...userProfile, university: e.target.value})}
                      placeholder="e.g. Heidelberg University"
                      className="w-full bg-slate-50 border border-slate-200 p-2.5 text-xs font-bold focus:ring-1 focus:ring-slate-900 focus:outline-none rounded-xs transition-all"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5 font-mono">Preferred Specialty</label>
                    <input 
                      type="text"
                      value={userProfile.interest}
                      onChange={e => setUserProfile({...userProfile, interest: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-200 p-2.5 text-xs font-bold focus:ring-1 focus:ring-slate-900 focus:outline-none rounded-xs transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block mb-2 font-mono flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-slate-500" />
                    Clinical Experience Highlights
                  </label>
                  <textarea 
                    rows={3}
                    value={userProfile.experience}
                    onChange={e => setUserProfile({...userProfile, experience: e.target.value})}
                    placeholder="Briefly describe what department postings or past ward experience you have. Keep it brief..."
                    className="w-full bg-slate-50 border border-slate-200 p-3 text-xs font-bold focus:ring-1 focus:ring-slate-900 focus:outline-none rounded-xs transition-all resize-none"
                  />
                </div>

                {/* Secure storage vault document management inside modal */}
                <div className="pt-6 border-t border-slate-150">
                  <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block mb-1.5 font-mono flex items-center justify-between">
                    <span>Uploaded Documents Vault (CV, References)</span>
                    {isUploading && <RefreshCcw className="w-3 h-3 animate-spin text-slate-700" />}
                  </label>
                  
                  <div className="space-y-2 mb-4">
                    {uploadedFiles.map(file => (
                      <div key={file} className="flex items-center justify-between bg-slate-50/80 p-2 border border-slate-250 rounded-xs group">
                        <div className="flex items-center gap-2 overflow-hidden">
                          <FileText className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                          <span className="text-xs text-slate-700 font-bold truncate">
                            {file.split('-').slice(1).join('-')}
                          </span>
                        </div>
                        <button 
                          type="button"
                          onClick={() => handleDeleteFile(file)}
                          className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-500 transition-all focus:opacity-100"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                    {uploadedFiles.length === 0 && (
                      <p className="text-[9px] text-slate-400 font-bold italic text-center py-5 border border-dashed border-slate-250">
                        Vault folder is empty. Upload documents below to attach payload with mail dispatcher.
                      </p>
                    )}
                  </div>

                  <div className="relative">
                    <input 
                      type="file" 
                      id="profile-vault-upload"
                      onChange={handleFileUpload}
                      className="hidden" 
                      accept=".pdf,.doc,.docx,.png,.jpg"
                    />
                    <label 
                      htmlFor="profile-vault-upload"
                      className="flex items-center justify-center gap-2 w-full py-3 border border-dashed border-slate-200 rounded-xs hover:border-slate-400 hover:bg-slate-50 transition-all cursor-pointer text-[9px] font-bold text-slate-500 uppercase tracking-wider font-mono shadow-xs"
                    >
                      Upload Vault Document
                    </label>
                  </div>
                </div>

                <div className="pt-4 flex items-center justify-end">
                  <button 
                    type="submit"
                    className="flex items-center gap-2 px-6 py-2 bg-slate-950 text-white font-mono text-[9px] font-bold uppercase tracking-widest hover:bg-black transition-all rounded-xs shadow-sm"
                  >
                    <Save className="w-4 h-4" />
                    Save Configuration
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* MODAL 3: AI Fit aligner drawer dashboard */}
      <AnimatePresence>
        {analyzingPos && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 text-left"
          >
            <motion.div 
              initial={{ scale: 0.96, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.96, opacity: 0, y: 15 }}
              className="bg-white w-full max-w-xl shadow-xl rounded-sm overflow-hidden flex flex-col h-[600px]"
            >
              <div className="p-5 border-b border-secondary bg-slate-50 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4.5 h-4.5 text-sky-600 animate-pulse" />
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 uppercase tracking-widest font-mono">AI ALIGNMENT PROFILE FIT CHECK</h3>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tight mt-0.5">{analyzingPos.hospital}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setAnalyzingPos(null)}
                  className="p-1.5 hover:bg-slate-100 rounded-full transition-colors"
                >
                  <X className="w-4.5 h-4.5 text-slate-400" />
                </button>
              </div>

              {/* Drawer Work Scroll */}
              <div className="flex-1 overflow-y-auto p-6 flex flex-col bg-white">
                {isFitLoading ? (
                  <div className="flex-1 flex flex-col items-center justify-center text-slate-400 gap-4">
                    <RefreshCcw className="w-7 h-7 animate-spin text-slate-900" />
                    <p className="text-[10px] font-bold uppercase tracking-widest animate-pulse font-mono">CALCULATING CLINICAL MATCH INTEGRITY MATRIX...</p>
                  </div>
                ) : fitAnalysis ? (
                  <div className="space-y-6">
                    {/* Score section */}
                    <div className="flex items-center gap-6 border-b border-slate-100 pb-5">
                      <div className="relative w-20 h-20 shrink-0">
                        <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                          <circle cx="18" cy="18" r="15.915" fill="none" stroke="#f1f5f9" strokeWidth="4.5" />
                          <circle 
                            cx="18" 
                            cy="18" 
                            r="15.915" 
                            fill="none" 
                            stroke={fitAnalysis.score > 80 ? '#10b981' : (fitAnalysis.score > 60 ? '#f59e0b' : '#ef4444')} 
                            strokeWidth="4.5" 
                            strokeDasharray={`${fitAnalysis.score} ${100 - fitAnalysis.score}`}
                          />
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center font-mono">
                          <span className="font-bold text-xl text-slate-900">{fitAnalysis.score}%</span>
                        </div>
                      </div>
                      <div>
                        <h4 className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Alignment Score</h4>
                        <p className="text-xs font-semibold text-slate-700 leading-relaxed mt-1">
                          {fitAnalysis.relevanceSummary}
                        </p>
                      </div>
                    </div>

                    {/* Strengths */}
                    <div className="space-y-2 text-xs">
                      <h4 className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Core Alignment Positive Strengths</h4>
                      <ul className="space-y-1.5">
                        {fitAnalysis.pros.map((p, idx) => (
                          <li key={idx} className="flex gap-2 text-slate-700 font-semibold leading-relaxed">
                            <span className="text-emerald-500 font-bold shrink-0">✓</span>
                            <span>{p}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Gaps */}
                    <div className="space-y-2 text-xs">
                      <h4 className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Identified Gaps or Practical Constraints</h4>
                      <ul className="space-y-1.5">
                        {fitAnalysis.cons.map((c, idx) => (
                          <li key={idx} className="flex gap-2 text-slate-700 font-semibold leading-relaxed">
                            <span className="text-red-400 font-bold shrink-0">!</span>
                            <span>{c}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Strategy Recommendations */}
                    <div className="space-y-2 text-xs border-t border-slate-100 pt-5">
                      <h4 className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Application Campaign Strategy</h4>
                      <ul className="space-y-2">
                        {fitAnalysis.strategy.map((s, idx) => (
                          <li key={idx} className="flex gap-2.5 text-slate-600 font-medium leading-relaxed">
                            <ArrowRight className="w-3.5 h-3.5 text-sky-500 shrink-0 mt-0.5" />
                            <span>{s}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center text-slate-400">
                    <AlertCircle className="w-8 h-8 opacity-20 mb-2" />
                    <p className="text-xs">Failed to calculate alignment matrix.</p>
                  </div>
                )}
              </div>

              {/* Aligner footer */}
              <div className="p-5 bg-slate-50 border-t border-slate-100 flex items-center justify-end shrink-0">
                <button 
                  onClick={() => setAnalyzingPos(null)}
                  className="px-5 py-2 hover:bg-slate-200 bg-slate-100 text-[9px] font-bold text-slate-600 font-mono tracking-widest uppercase rounded-xs transition-colors"
                >
                  Close Matrix
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
